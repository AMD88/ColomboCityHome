<!DOCTYPE HTML>
<html>

<head>
	
	<title>PHP Blogs by Graeson Lewis</title>

	<!-- Import Blueprint CSS -->
	<link rel="stylesheet" href="http://localhost/8-codeigniter/blog/css/blueprint/screen.css" type="text/css" media="screen, projection">
	
	<!--Import Site CSS -->
    <link rel="stylesheet" href="http://localhost/~Graeson/php/apps/blog/css/styles.css" type="text/css" media="screen, projection">

<head>
	
<body>

	<div class="container">

		<h1>Simple Blog - CodeIgniter</h1>
		<h3><?php echo anchor('blog/create', 'Add Post'); ?></h3>
		<hr />
